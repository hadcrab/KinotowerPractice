@extends('admin.layout.main')

@section('title', 'Main page')

@section('content')
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda atque, consequatur consequuntur cumque delectus ducimus harum incidunt iste laborum laudantium nihil nobis quam saepe vel, veniam. At earum sapiente sequi?</p>
@endsection
