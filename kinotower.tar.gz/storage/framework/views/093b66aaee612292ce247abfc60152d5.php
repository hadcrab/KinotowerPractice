<?php $__env->startSection('content'); ?>
<div class="content-wrapper p-3">
<section class="content-header">
<div class="container-fluid">
<h1><?php echo e(isset($film) ? 'Редактировать фильм' : 'Добавить фильм'); ?></h1>
</div>
</section>


<section class="content">
<div class="card card-primary">
<div class="card-header">
<h3 class="card-title"><?php echo e(isset($film) ? 'Редактирование' : 'Создание'); ?></h3>
</div>


<form action="<?php echo e(isset($film) ? route('films.update', $film->id) : route('films.store')); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php if(isset($film)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>


<div class="card-body">
<div class="form-group">
<label>Название</label>
<input type="text" name="name" class="form-control" value="<?php echo e($film->name ?? ''); ?>" required>
</div>
<div class="form-group">
<label>Страна</label>
<select name="country_id" class="form-control" required>
<option disabled selected>Выберите страну</option>
<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($country->id); ?>" <?php if(isset($film) && $film->country_id == $country->id): ?> selected <?php endif; ?>>
<?php echo e($country->name); ?>

</option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<div class="form-group">
<label>Длительность (мин)</label>
<input type="number" name="duration" class="form-control" value="<?php echo e($film->duration ?? ''); ?>" required>
</div>
<div class="form-group">
<label>Год выпуска</label>
<input type="number" name="year_of_issue" class="form-control" value="<?php echo e($film->year_of_issue ?? ''); ?>" required>
</div>
<div class="form-group">
<label>Возрастной рейтинг</label>
<input type="text" name="age" class="form-control" value="<?php echo e($film->age ?? ''); ?>" required>
</div>
<div class="form-group">
<label>Постер (URL)</label>
<input type="text" name="link_img" class="form-control" value="<?php echo e($film->link_img ?? ''); ?>">
</div>
<div class="form-group">
<label>Кинопоиск (URL)</label>
<input type="text" name="link_kinopoisk" class="form-control" value="<?php echo e($film->link_kinopoisk ?? ''); ?>">
</div>
<div class="form-group">
<label>Видео (URL)</label>
<input type="text" name="link_video" class="form-control" value="<?php echo e($film->link_video ?? ''); ?>">
</div>
</div>


<div class="card-footer">
<button type="submit" class="btn btn-primary">Сохранить</button>
</div>
</form>
</div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mihail/projects/KinotowerPractice/resources/views/admin/films/form.blade.php ENDPATH**/ ?>