<?php $__env->startSection('title', isset($country) ? 'Edit country: '.$country->name : 'Add country'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <form action="<?php echo e(isset($country) ? route('countries.update', $country->id) : route('countries.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(isset($country)): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <label class="form-label" for="name">Name</label>
                <input class="form-control" name="name" id="name" type="text" value="<?php echo e(isset($country) ? old('name', $country->name) : old('name')); ?>">

            <div class="mt-4">
                <button class="btn btn-outline-success" type="submit">save</button>
            </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mihail/projects/KinotowerPractice/resources/views/admin/countries/create.blade.php ENDPATH**/ ?>