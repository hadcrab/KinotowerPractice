<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h3 class="mb-4">Genres of film: <strong><?php echo e($film->name); ?></strong></h3>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Add new genre</h3>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('film.categories.store', $film->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-6">
                        <select name="category_id" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <button class="btn btn-success">Add</button>
                    </div>
                </div>

            </form>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h3 class="card-title">Existing genres</h3>
        </div>

        <div class="card-body">

            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Name</th>
                    <th width="150px">Actions</th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $filmCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cat->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('film.categories.destroy', [$film->id, $cat->id])); ?>"
                                  method="POST"
                                  onsubmit="return confirm('Delete genre?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mihail/projects/KinotowerPractice/resources/views/admin/films/categories/index.blade.php ENDPATH**/ ?>