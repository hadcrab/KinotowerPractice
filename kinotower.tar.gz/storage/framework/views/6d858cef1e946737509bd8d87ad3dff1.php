<?php $__env->startSection('content'); ?>
<h2>Редактировать фильм</h2>

<form method="POST" action="<?php echo e(route('films.update', $film->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <input name="name" value="<?php echo e($film->name); ?>">

    <select name="country_id">
        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>" <?php if($film->country_id == $c->id): echo 'selected'; endif; ?>>
                <?php echo e($c->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <input name="duration" value="<?php echo e($film->duration); ?>">

    <input name="year_of_issue" value="<?php echo e($film->year_of_issue); ?>">

    <input name="age" value="<?php echo e($film->age); ?>">

    <input name="link_img" value="<?php echo e($film->link_img); ?>">

    <input name="link_kinopoisk" value="<?php echo e($film->link_kinopoisk); ?>">

    <input name="link_video" value="<?php echo e($film->link_video); ?>">

    <h4>Жанры:</h4>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label>
            <input type="checkbox"
                   name="categories[]"
                   value="<?php echo e($cat->id); ?>"
                   <?php if(in_array($cat->id, $selected_categories)): echo 'checked'; endif; ?>
            >
            <?php echo e($cat->name); ?>

        </label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button>Сохранить</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mihail/projects/KinotowerPractice/resources/views/admin/films/edit.blade.php ENDPATH**/ ?>