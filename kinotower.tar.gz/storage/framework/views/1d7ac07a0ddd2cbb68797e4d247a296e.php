<?php $__env->startSection('title', isset($category) ? 'Edit genre: '.$category->name : 'Add new genre'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <form action="<?php echo e(isset($category) ? route('categories.update', $category->id) : route('categories.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(isset($category)): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <label class="form-label" for="name">Name</label>
                <input class="form-control" name="name" id="name" type="text" value="<?php echo e(isset($category) ? old('name', $category->name) : old('name')); ?>">
                <div class="mt-4">
                    <label class="form-label" for="parent_id">Parent genre</label>
                    <select name="parent_id" id="parent_id" class="form-select">
                        <option value="">No parent genre</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(isset($category)
                                    && $category->itemCategory
                                    && $category->itemCategory->id === $itemCategory->id): echo 'selected'; endif; ?>
                                    value="<?php echo e($itemCategory->id); ?>">
                                <?php echo e($itemCategory->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mt-4">
                    <button class="btn btn-outline-success" type="submit">save</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mihail/projects/KinotowerPractice/resources/views/admin/categories/create.blade.php ENDPATH**/ ?>