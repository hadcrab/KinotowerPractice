<?php $__env->startSection('content'); ?>
<div class="content-wrapper p-3">
<section class="content-header">
<div class="container-fluid">
<div class="row mb-2">
<div class="col-sm-6">
<h1>Фильмы</h1>
</div>
<div class="col-sm-6 text-right">
<a href="<?php echo e(route('films.create')); ?>" class="btn btn-primary">Добавить фильм</a>
</div>
</div>
</div>
</section>


<section class="content">
<div class="card">
<div class="card-header">
<h3 class="card-title">Список фильмов</h3>
</div>
<div class="card-body table-responsive p-0">
<table class="table table-hover text-nowrap">
<thead>
<tr>
<th>ID</th>
<th>Название</th>
<th>Год</th>
<th>Страна</th>
<th>Возраст</th>
<th>Действия</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($film->id); ?></td>
<td><?php echo e($film->name); ?></td>
<td><?php echo e($film->year_of_issue); ?></td>
<td><?php echo e($film->country->name ?? '-'); ?></td>
<td><?php echo e($film->age); ?></td>
<td>
<a href="<?php echo e(route('films.edit', $film->id)); ?>" class="btn btn-sm btn-warning">Редактировать</a>
<form action="<?php echo e(route('films.destroy', $film->id)); ?>" method="POST" style="display:inline-block;">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button class="btn btn-sm btn-danger" onclick="return confirm('Удалить фильм?')">Удалить</button>
</form>
</td>
<td>
<a href="<?php echo e(route('film.categories.index', $film->id)); ?>" class="btn btn-info btn-sm">
    Жанры
</a>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>


<div class="card-footer clearfix">
<?php echo e($films->links()); ?>

</div>
</div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mihail/projects/KinotowerPractice/resources/views/admin/films/index.blade.php ENDPATH**/ ?>