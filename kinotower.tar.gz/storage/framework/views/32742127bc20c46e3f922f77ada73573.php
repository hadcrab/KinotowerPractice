<?php $__env->startSection('title', 'Main page'); ?>

<?php $__env->startSection('content'); ?>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda atque, consequatur consequuntur cumque delectus ducimus harum incidunt iste laborum laudantium nihil nobis quam saepe vel, veniam. At earum sapiente sequi?</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mihail/projects/KinotowerPractice/resources/views/admin/index.blade.php ENDPATH**/ ?>