<?php $__env->startSection('content'); ?>
<h2>Добавить фильм</h2>

<form method="POST" action="<?php echo e(route('films.store')); ?>">
    <?php echo csrf_field(); ?>

    <input name="name" placeholder="Название">

    <select name="country_id">
        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <input name="duration" placeholder="Длительность (мин)">

    <input name="year_of_issue" placeholder="Год выпуска">

    <input name="age" placeholder="Возрастной рейтинг">

    <input name="link_img" placeholder="Ссылка на изображение">

    <input name="link_kinopoisk" placeholder="Ссылка на Кинопоиск">

    <input name="link_video" placeholder="Ссылка на видео">

    <h4>Жанры:</h4>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label>
            <input type="checkbox" name="categories[]" value="<?php echo e($cat->id); ?>">
            <?php echo e($cat->name); ?>

        </label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button>Сохранить</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mihail/projects/KinotowerPractice/resources/views/admin/films/create.blade.php ENDPATH**/ ?>